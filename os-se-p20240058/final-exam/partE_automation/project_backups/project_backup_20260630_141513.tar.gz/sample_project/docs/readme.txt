Beacon launch documentation
